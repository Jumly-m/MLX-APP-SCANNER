<?php
error_reporting(0);
include 'config.data';

use PHPMailer\PHPMailer\PHPMailer;
require_once 'phpmailer/Exception.php';
require_once 'phpmailer/PHPMailer.php';
require_once 'phpmailer/SMTP.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$input = file_get_contents("php://input");

if($_SERVER['REQUEST_METHOD'] == "POST")
{
	if(isset($input)) 
	{	
		$post = json_decode($input);
		switch($post->call)
		{
			case "register":
				$result = register($post) ;
				break;
			case "login":
				$result = login($post) ;
				break;
			case "forgetpassword":
				$result = forgetpassword($post) ;
				break;
			case "updateprofile":
				$result = updateProfile($post) ;
				break;
			case "referral":
				$result = getReferal($post) ;
				break;
			case "addlog":
				$result = addlog($post) ;
				break;
			case "scanlog":
				$result = scanlog($post) ;
				break;
			case "withdrawreq":
				$result = withdrawreq($post) ;
				break;
			case "getwithdrawreq":
				$result = getWithdrawreqStatus($post) ;
				break;
			case "balance":
				$result = getbalance($post) ;
				break;
			default : $result = array(status => false, msg => 'Invalid method call');
		}
	} else $result = array(status => false, msg => 'Invalid access');
} else $result = array(status => false, msg => 'Invalid request');

echo json_encode($result);


function register($post)
{
	global $conn;
	$reqdata = $post->reqdata;

	// check user exist not not
	$sql = "select id from users where email = '$reqdata[1]'";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	if ($isDataExist > 0){
		$result['msg'] = "Email already registered";
		$result['status'] = false;
		return $result;
	}

	// check the referral code
	$coin = 0;
	$referralid = 0;
	if (!empty($reqdata[3])) {
		$sql = "select * from referral where refercode = '$reqdata[3]'";
		$query_result = mysqli_query($conn, $sql);
        $isDataExist = mysqli_num_rows($query_result);
		if ($isDataExist > 0){
			$coin = 2;
			$dt = $query_result->fetch_assoc();
			$referralid = $dt['userid'];
			$sql = "update users set coin = coin + $coin where id = '$referralid'";
			mysqli_query($conn,$sql);
			$coin = 1;
		} else {
			$result['msg'] = "Referral code not valid";
			$result['status'] = false;
			return $result;
		}
	}

	// perform registration
	$sql = "insert into users (name,email,password,coin,status,referrby) values ('$reqdata[0]','$reqdata[1]',MD5('$reqdata[2]'),'$coin','1','$referralid')";
	
	if (mysqli_query($conn,$sql)) {
		$result['msg'] = "Registration succesful";
		$result['status'] = true;
	} else {
		$result['msg'] = "Unable to register. Please try later";
		$result['status'] = false;
	}

	return $result;
}

function getReferal($post)
{
	global $conn;
	$reqdata = $post->reqdata;

	// check user exist or not
	$sql = "select refercode from referral where userid = '$reqdata[0]'";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	if ($isDataExist > 0){
		$dt = $query_result->fetch_assoc();
		$result['code'] =  $dt['refercode'];
		$result['status'] = true;
		return $result;
	}

	// perform registration
	$sql = "insert into referral (refercode,userid) values (SUBSTR(MD5(RAND()), 1, 8),'$reqdata[0]')";
	
	if (mysqli_query($conn,$sql)) {
		$sql = "select refercode from referral where userid = '$reqdata[0]'";
		$query_result = mysqli_query($conn, $sql);
		$dt = $query_result->fetch_assoc();
		$result['code'] =  $dt['refercode'];
		$result['status'] = true;
	} else {
		$result['msg'] = "Unable to register. Please try later";
		$result['status'] = false;
	}

	return $result;
}

function login($post)
{
	global $conn;
	$reqdata = $post->reqdata;

	$sql = "select id,name,email,address,coin from users where email = '$reqdata[0]' and password = MD5('$reqdata[1]') and status <> 0";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	if ($isDataExist > 0){
		$dt = $query_result->fetch_assoc();
		$result['data'] =  $dt;
		$result['msg'] =  "Login succesful";
		$result['status'] = true;
	} else {
		$result['msg'] =  "Invalid credential.";
		$result['status'] = false;
	}

	return $result;
}

function forgetpassword($post)
{
	global $conn,$EMAIL,$PASSWORD;
	$reqdata = $post->reqdata;

	$sql = "select id,name,email,address,coin from users where email = '$reqdata[0]' and status <> 0";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	if ($isDataExist > 0){
		$dt = $query_result->fetch_assoc();
		$result['data'] =  $dt;

		// generate and update password
		$pass = randomPassword();
		$id = $dt['id'];
		$name = $dt['name'];
		$email = $dt['email'];
		$sql = "update users set password = MD5('$pass') where id = $id";
		if (mysqli_query($conn,$sql)) {
			try{
				$phpmailer = new PHPMailer();
				$phpmailer->Host = "mail.mlxqr.defiverse.tech";
				$phpmailer->SMTPAuth = true;
				$phpmailer->Port = 587;
				$phpmailer->SMTPSecure = 'tls'; 
				$phpmailer->Username = $EMAIL;
				$phpmailer->Password = $PASSWORD;
				// $phpmailer->setFrom($EMAIL);
				$phpmailer->From = $EMAIL;
				// $phpmailer->FromName = "App Team";
				$phpmailer->addAddress($email);
				$phpmailer->isHTML(true);
				$phpmailer->Subject = 'Reset Password';
				$phpmailer->Body = "Welcome $name. Your new password for login is: $pass";
				if(!$phpmailer->Send()) {
					$result['msg'] =  "Password reset but unable to send email.";
					$result['status'] = false;
				} else {
					$result['msg'] =  "Please check your email. A new password is send to your email for login.";
					$result['status'] = true;
				}

			} catch (Exception $e){
				$result['msg'] =  "Password reset but unable to send email.";
				$result['status'] = false;
			}
		} else {
			$result['msg'] =  "Failed to reset password.";
			$result['status'] = false;
		}
	} else {
		$result['msg'] =  "Invalid email address.";
		$result['status'] = false;
	}

	return $result;
}

function updateProfile($post)
{
	global $conn;
	$reqdata = $post->reqdata;

	$sql = "update users set name='$reqdata[1]',address='$reqdata[2]',update_at=now() where id='$reqdata[0]'";
	
	if (mysqli_query($conn,$sql)) {
		$result['msg'] = "Update succesful";
		$result['status'] = true;
	} else {
		$result['msg'] = "Unable to update. Please try later";
		$result['status'] = false;
	}

	return $result;
}

function addlog($post)
{
	global $conn;
	$reqdata = $post->reqdata;

	$sql = "select userid from scanlog where userid = '$reqdata[0]' and scandata = '$reqdata[1]'";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	$coin = 0;
	if ($isDataExist == 0){
		$sql = "insert into scanlog (userid,scandata) values ('$reqdata[0]','$reqdata[1]')";
		mysqli_query($conn,$sql);
		$coin = 1;
		$sql = "update users set coin = coin + $coin where id = '$reqdata[0]'";
		mysqli_query($conn,$sql);
		$result['status'] = true;
		$result['msg'] =  "Added +0.5 MLXCoin";
	} else {
		$result['status'] = false;
		$result['msg'] =  "Duplicate scan. No coin added.";
	}
	
	return $result;
}

function scanlog($post)
{
	global $conn;
	$reqdata = $post->reqdata;
	$sql = "select scandata,scanat from scanlog where userid = '$reqdata[0]' order by id desc";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	if ($isDataExist>0) {
		while ($row = mysqli_fetch_assoc($query_result)) {
			$data[] = $row;
		}
		$result['status'] = true;
		$result['data'] = $data;
	} else {
		$result['status'] = false;
	}

	return $result;
}

function withdrawreq($post)
{
	global $conn;
	$reqdata = $post->reqdata;

	// Checking minimum amount
	if($reqdata[3]<10) {
		$result['msg'] = "Minimum transaction amount is 10 MLXCoin";
		$result['status'] = false;
		return $result;
	}

	// Check is the amount is available in the account
	$sql = "select coin from users where id = '$reqdata[0]'";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	if ($isDataExist > 0){

		$dt = $query_result->fetch_assoc();
		if($dt['coin'] < $reqdata[3]) {
			$result['msg'] = "Your account have not valid fund";
			$result['status'] = false;
			return $result;
		}

		$sql = "insert into reqwithdraw (userid,name,address,amount,created_at,status) values ('$reqdata[0]','$reqdata[1]','$reqdata[2]','$reqdata[3]',now(),0)";
		
		if (mysqli_query($conn,$sql)) {
			$result['msg'] = "Initiated withdrawal request";
			$result['status'] = true;
		}
		else {
			$result['msg'] = "Unable to process your request right now. Please try later";
			$result['status'] = false;
			$result['sql'] = $sql;
		}
	}
	else 
	{
		$result['msg'] = "User not exisit in the system.";
		$result['status'] = false;
	}

	return $result;
}


function getWithdrawreqStatus($post)
{
	global $conn;
	$reqdata = $post->reqdata;
	$sql = "select * from reqwithdraw where userid = '$reqdata[0]' order by id desc";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	if ($isDataExist>0) {
		while ($row = mysqli_fetch_assoc($query_result)) {
			$data[] = $row;
		}
		$result['status'] = true;
		$result['data'] = $data;
	} else {
		$result['status'] = false;
	}

	return $result;
}



function getbalance($post) {
	global $conn;
	$reqdata = $post->reqdata;
	$sql = "select coin from users where id = '$reqdata[0]'";
	$query_result = mysqli_query($conn, $sql);
	$isDataExist = mysqli_num_rows($query_result);
	if ($isDataExist > 0){
		$dt = $query_result->fetch_assoc();
		$result['msg'] = "Balance update success";
		$result['coin'] = $dt['coin'];
		$result['status'] = true;
	}
	else 
	{
		$result['msg'] = "User not exisit in the system.";
		$result['status'] = false;
	}
	return $result;
}

function randomPassword() {
	$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
}


?>